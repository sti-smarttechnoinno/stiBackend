<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'sku',
        'slug',
        'category',
        'brand',
        'product_type',
        'value',
        'status',
        'image',
        'translations',
    ];

    protected $casts = [
        'translations' => 'array',
    ];
}
