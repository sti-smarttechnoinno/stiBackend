<?php

namespace App\Http\Controllers;

use App\Models\TeamMember;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class TeamController extends Controller
{
    public function index(): JsonResponse
    {
        $members = TeamMember::orderBy('id', 'asc')->get();
        return response()->json($members);
    }

    public function store(Request $request): JsonResponse
    {
        $payload = $request->all();
        $membersData = [];

        if (is_array($payload) && array_is_list($payload)) {
            $membersData = $payload;
        } elseif (isset($payload['members']) && is_array($payload['members'])) {
            $membersData = $payload['members'];
        }

        $savedIds = [];
        foreach ($membersData as $item) {
            $rawId = $item['id'] ?? null;
            $id = is_numeric($rawId) && (float)$rawId < 2147483647 ? (int)$rawId : null;

            if ($id && TeamMember::find($id)) {
                $member = TeamMember::find($id);
                $member->update([
                    'name' => $item['name'] ?? '',
                    'position' => $item['position'] ?? '',
                    'initials' => $item['initials'] ?? null,
                    'image' => $item['image'] ?? null,
                    'linkedin' => $item['linkedin'] ?? null,
                    'translations' => $item['translations'] ?? null,
                ]);
            } else {
                $member = TeamMember::create([
                    'name' => $item['name'] ?? '',
                    'position' => $item['position'] ?? '',
                    'initials' => $item['initials'] ?? null,
                    'image' => $item['image'] ?? null,
                    'linkedin' => $item['linkedin'] ?? null,
                    'translations' => $item['translations'] ?? null,
                ]);
            }
            $savedIds[] = $member->id;
        }

        // Delete any members not included in savedIds
        TeamMember::whereNotIn('id', $savedIds)->delete();

        $all = TeamMember::orderBy('id', 'asc')->get();
        return response()->json($all);
    }
}
