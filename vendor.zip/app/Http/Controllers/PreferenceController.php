<?php

namespace App\Http\Controllers;

use App\Models\Preference;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class PreferenceController extends Controller
{
    private function getDefaultPreferences(): array
    {
        return [
            'phone' => '0550 123 456',
            'whatsapp' => '0550 123 456',
            'email' => 'contact@sti.dz',
            'address' => [
                'en' => 'Lot 24, Zone Industrielle, Bab Ezzouar, Algiers, Algeria',
                'ar' => 'المنطقة الصناعية رقم 24، باب الزوار، الجزائر العاصمة',
                'fr' => 'Lot 24, Zone Industrielle, Bab Ezzouar, Alger, Algérie',
            ],
            'gmapsEmbed' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3236.4678129532675!2d5.4263334!3d36.1878916!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12f315007983d29b%3A0xb969c549a0ef2f09!2sSARL%20Smart%20Technologie%20Innovation%20-%20STI!5e0!3m2!1sen!2sdz!4v1700000000000!5m2!1sen!2sdz',
            'emergencyContact' => '',
            'businessInfo' => [
                'companyName' => [
                    'en' => 'SARL Smart Technologie Innovation',
                    'ar' => 'ذ.م.م سمارت تكنولوجي إينوفيشين',
                    'fr' => 'SARL Smart Technologie Innovation',
                ],
            ],
            'socialMedia' => [
                'facebook' => 'https://facebook.com/sti.algeria',
                'linkedin' => 'https://linkedin.com/company/sti-algeria',
                'twitter' => 'https://twitter.com/sti_algeria',
                'youtube' => 'https://youtube.com/@sti_algeria',
                'instagram' => '',
            ],
            'businessHours' => [
                'saturday' => ['open' => '08:00', 'close' => '17:00', 'isClosed' => false],
                'sunday' => ['open' => '08:00', 'close' => '17:00', 'isClosed' => false],
                'monday' => ['open' => '08:00', 'close' => '17:00', 'isClosed' => false],
                'tuesday' => ['open' => '08:00', 'close' => '17:00', 'isClosed' => false],
                'wednesday' => ['open' => '08:00', 'close' => '17:00', 'isClosed' => false],
                'thursday' => ['open' => '08:00', 'close' => '17:00', 'isClosed' => false],
                'friday' => ['open' => '00:00', 'close' => '00:00', 'isClosed' => true],
            ],
            'statistics' => [
                'provincesServed' => '58',
                'officialProducts' => '100%',
                'businessPartners' => '1000+',
                'averageResponse' => '24h',
            ],
        ];
    }

    public function show(): JsonResponse
    {
        $pref = Preference::where('key', 'global_preferences')->first();
        if ($pref && is_array($pref->value)) {
            return response()->json($pref->value);
        }
        return response()->json($this->getDefaultPreferences());
    }

    public function update(Request $request): JsonResponse
    {
        $pref = Preference::where('key', 'global_preferences')->first();
        $current = $pref && is_array($pref->value) ? $pref->value : $this->getDefaultPreferences();
        $body = $request->all();

        $updatedPreferences = [
            'phone' => $body['phone'] ?? $current['phone'] ?? '0550 02 35 36',
            'whatsapp' => $body['whatsapp'] ?? $current['whatsapp'] ?? '0550 02 35 36',
            'email' => $body['email'] ?? $current['email'] ?? 'administration@sti.dz',
            'address' => $body['address'] ?? $current['address'] ?? [],
            'gmapsEmbed' => $body['gmapsEmbed'] ?? $current['gmapsEmbed'] ?? '',
            'emergencyContact' => $body['emergencyContact'] ?? $current['emergencyContact'] ?? '',
            'businessInfo' => isset($body['businessInfo']) ? [
                'companyName' => $body['businessInfo']['companyName'] ?? ($current['businessInfo']['companyName'] ?? []),
            ] : ($current['businessInfo'] ?? []),
            'socialMedia' => $body['socialMedia'] ?? $current['socialMedia'] ?? [],
            'businessHours' => $body['businessHours'] ?? $current['businessHours'] ?? [],
            'statistics' => $body['statistics'] ?? $current['statistics'] ?? [],
        ];

        // Clean out legacy rc/nif/nis/article numbers if present
        if (isset($updatedPreferences['businessInfo']['rcNumber'])) unset($updatedPreferences['businessInfo']['rcNumber']);
        if (isset($updatedPreferences['businessInfo']['nifNumber'])) unset($updatedPreferences['businessInfo']['nifNumber']);
        if (isset($updatedPreferences['businessInfo']['nisNumber'])) unset($updatedPreferences['businessInfo']['nisNumber']);
        if (isset($updatedPreferences['businessInfo']['articleNumber'])) unset($updatedPreferences['businessInfo']['articleNumber']);

        $pref = Preference::updateOrCreate(
            ['key' => 'global_preferences'],
            ['value' => $updatedPreferences]
        );

        return response()->json([
            'success' => true,
            'preferences' => $pref->value,
        ]);
    }
}
