<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ProductController extends Controller
{
    /**
     * Display a listing of all products.
     */
    public function index(): JsonResponse
    {
        $products = Product::orderBy('id', 'asc')->get();
        return response()->json($products);
    }

    /**
     * Display the specified product by slug or ID.
     */
    public function show(string $slugOrId): JsonResponse
    {
        $product = Product::where('slug', $slugOrId)
            ->orWhere('id', is_numeric($slugOrId) ? (int)$slugOrId : 0)
            ->first();

        if (!$product) {
            return response()->json(['error' => 'Product not found'], 404);
        }

        return response()->json($product);
    }

    /**
     * Store a newly created product in storage.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'sku' => 'required|string|unique:products,sku',
            'slug' => 'required|string|unique:products,slug',
            'category' => 'required|string',
            'brand' => 'nullable|string',
            'productType' => 'nullable|string',
            'value' => 'nullable|string',
            'status' => 'nullable|string',
            'image' => 'nullable|string',
            'translations' => 'required|array',
        ]);

        $product = Product::create([
            'sku' => $validated['sku'],
            'slug' => $validated['slug'],
            'category' => $validated['category'],
            'brand' => $validated['brand'] ?? 'Ooredoo',
            'product_type' => $validated['productType'] ?? 'SIM Card',
            'value' => $validated['value'] ?? 'Prepaid',
            'status' => $validated['status'] ?? 'Published',
            'image' => $validated['image'] ?? null,
            'translations' => $validated['translations'],
        ]);

        // Standardize returning camelCase field for frontend Product Type compatibility
        $product->productType = $product->product_type;

        return response()->json($product, 201);
    }

    /**
     * Update the specified product in storage.
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $product = Product::find($id);

        if (!$product) {
            return response()->json(['error' => 'Product not found'], 404);
        }

        $validated = $request->validate([
            'sku' => 'required|string|unique:products,sku,' . $id,
            'slug' => 'required|string|unique:products,slug,' . $id,
            'category' => 'required|string',
            'brand' => 'nullable|string',
            'productType' => 'nullable|string',
            'value' => 'nullable|string',
            'status' => 'nullable|string',
            'image' => 'nullable|string',
            'translations' => 'required|array',
        ]);

        $product->update([
            'sku' => $validated['sku'],
            'slug' => $validated['slug'],
            'category' => $validated['category'],
            'brand' => $validated['brand'] ?? $product->brand,
            'product_type' => $validated['productType'] ?? $product->product_type,
            'value' => $validated['value'] ?? $product->value,
            'status' => $validated['status'] ?? $product->status,
            'image' => $validated['image'] ?? $product->image,
            'translations' => $validated['translations'],
        ]);

        $product->productType = $product->product_type;

        return response()->json($product);
    }

    /**
     * Remove the specified product from storage.
     */
    public function destroy(int $id): JsonResponse
    {
        $product = Product::find($id);

        if (!$product) {
            return response()->json(['error' => 'Product not found'], 404);
        }

        $product->delete();

        return response()->json(['success' => true, 'message' => 'Product deleted']);
    }
}
