<?php

namespace App\Http\Controllers;

use App\Models\Career;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class CareerController extends Controller
{
    /**
     * Display a listing of all career openings.
     */
    public function index(Request $request): JsonResponse
    {
        $query = Career::orderBy('id', 'asc');

        if ($request->has('status')) {
            $query->where('status', $request->query('status'));
        }

        $careers = $query->get();
        return response()->json($careers);
    }

    /**
     * Display the specified career opening by slug or ID.
     */
    public function show(string $slugOrId): JsonResponse
    {
        $career = Career::where('slug', $slugOrId)
            ->orWhere('id', is_numeric($slugOrId) ? (int)$slugOrId : 0)
            ->first();

        if (!$career) {
            return response()->json(['error' => 'Job offer not found'], 404);
        }

        return response()->json($career);
    }

    /**
     * Store a newly created career opening in storage.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'slug' => 'required|string|unique:careers,slug',
            'department' => 'required|string',
            'location' => 'required|string',
            'type' => 'required|string',
            'experience' => 'nullable|string',
            'salary' => 'nullable|string',
            'status' => 'nullable|string',
            'translations' => 'required|array',
        ]);

        $career = Career::create([
            'slug' => $validated['slug'],
            'department' => $validated['department'],
            'location' => $validated['location'],
            'type' => $validated['type'],
            'experience' => $validated['experience'] ?? 'No experience',
            'salary' => $validated['salary'] ?? 'Competitive',
            'status' => $validated['status'] ?? 'Published',
            'translations' => $validated['translations'],
        ]);

        return response()->json($career, 201);
    }

    /**
     * Update the specified career opening in storage.
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $career = Career::find($id);

        if (!$career) {
            return response()->json(['error' => 'Job offer not found'], 404);
        }

        // Support partial status toggles from index lists
        if ($request->has('status') && count($request->all()) === 1) {
            $career->update(['status' => $request->status]);
            return response()->json($career);
        }

        $validated = $request->validate([
            'slug' => 'required|string|unique:careers,slug,' . $id,
            'department' => 'required|string',
            'location' => 'required|string',
            'type' => 'required|string',
            'experience' => 'nullable|string',
            'salary' => 'nullable|string',
            'status' => 'nullable|string',
            'translations' => 'required|array',
        ]);

        $career->update([
            'slug' => $validated['slug'],
            'department' => $validated['department'],
            'location' => $validated['location'],
            'type' => $validated['type'],
            'experience' => $validated['experience'] ?? $career->experience,
            'salary' => $validated['salary'] ?? $career->salary,
            'status' => $validated['status'] ?? $career->status,
            'translations' => $validated['translations'],
        ]);

        return response()->json($career);
    }

    /**
     * Remove the specified career opening from storage.
     */
    public function destroy(int $id): JsonResponse
    {
        $career = Career::find($id);

        if (!$career) {
            return response()->json(['error' => 'Job offer not found'], 404);
        }

        $career->delete();

        return response()->json(['success' => true, 'message' => 'Job offer deleted']);
    }
}
