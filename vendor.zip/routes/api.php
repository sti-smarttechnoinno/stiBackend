<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SolutionController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CareerController;
use App\Http\Controllers\AuthController;

use App\Http\Controllers\PreferenceController;
use App\Http\Controllers\TeamController;

// Public Auth Endpoints
Route::post('/login', [AuthController::class, 'login']);

// Public Read & Write Operations for Admin Console & Site
Route::get('/solutions', [SolutionController::class, 'index']);
Route::get('/solutions/{slug}', [SolutionController::class, 'show']);
Route::post('/solutions', [SolutionController::class, 'store']);
Route::put('/solutions/{id}', [SolutionController::class, 'update']);
Route::delete('/solutions/{id}', [SolutionController::class, 'destroy']);

Route::get('/products', [ProductController::class, 'index']);
Route::get('/products/{slugOrId}', [ProductController::class, 'show']);
Route::post('/products', [ProductController::class, 'store']);
Route::put('/products/{id}', [ProductController::class, 'update']);
Route::delete('/products/{id}', [ProductController::class, 'destroy']);

Route::get('/jobs', [CareerController::class, 'index']);
Route::get('/jobs/{slugOrId}', [CareerController::class, 'show']);
Route::post('/jobs', [CareerController::class, 'store']);
Route::put('/jobs/{id}', [CareerController::class, 'update']);
Route::delete('/jobs/{id}', [CareerController::class, 'destroy']);

Route::get('/preferences', [PreferenceController::class, 'show']);
Route::post('/preferences', [PreferenceController::class, 'update']);

Route::get('/team', [TeamController::class, 'index']);
Route::post('/team', [TeamController::class, 'store']);

// Protected Admin Endpoints
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
});
