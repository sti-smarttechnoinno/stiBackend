# Inertia + React

- IMPORTANT: Activate ___SINGLE_BACKTICK___inertia-react-development___SINGLE_BACKTICK___ when working with Inertia React client-side patterns.
<?php /**PATH C:\Users\RTD-003\Desktop\dev\backend\storage\framework\views/88b9a4f68c7688cc6a0339ed43d1669f.blade.php ENDPATH**/ ?>